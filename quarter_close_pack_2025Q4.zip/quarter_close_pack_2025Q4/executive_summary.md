# Quarterly Close Pack — 2025Q4

## Run Metadata
- Run ID: **2025Q4_MVP**
- Scenario: **RatesUp100_SpreadsUp50**
- Generated (UTC): **2025-12-22T00:17:10.687646Z**

## Key KPIs (Base vs Scenario)
- Assets MV: 173,414,144.77 → 162,966,361.11  (Δ -10,447,783.66)
- Liability PV: 79,588,566.06 → 75,797,168.33  (Δ -3,791,397.73)
- Surplus: 93,825,578.71 → 87,169,192.78  (Δ -6,656,385.93)

## Assumptions (Governance)
- See assumptions_diff_report.xlsx for curve/spread bps movements (YieldCurve_Diff and CreditSpreads_Diff).

## Reinvestment Strategy (Policy Overview)
- Liquidity reserve: keep **≥ 3%** cash (demo policy)
- Max below investment grade: **≤ 10%** allocation (demo policy)
- Duration target: **~5 years** within a band (demo policy)
- See reinvestment_inputs.xlsx for plan + summary.

## Attribution (Why surplus changed)
- Top driver: Asset rate impact = -6,965,189.11
- See Attribution sheet in kpi_dashboard.xlsx or attribution_summary.csv.

## Controls Evidence
- controls_evidence/controls_evidence_checklist.csv
- controls_evidence/run_manifest.csv
